/**
 * 
 */
/**
 * 
 */
module Chap10 {
	requires java.desktop;
}