/**
 * 
 */
/**
 * 
 */
module Chap07 {
	requires java.desktop;
}