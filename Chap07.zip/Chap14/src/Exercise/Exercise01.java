package Exercise;

public class Exercise01 {

	public static void main(String[] args) {
		

	}

}
