/*
package Lab;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Calculator extends JFrame {

	public static void main(String[] args) {
		private JPanel panel;
		private JTextFiedl tField;
		private JButton[] buttons;
		private String[] labels = {
				"Backspace", "", "", "CE", "C",
				"7", "8", "9", "/", "sqrt",
				"4", "5", "6", "x", "%",
				"1", "2", "3", "-", "1/x",
				"0", "+/-", ".", "+", "=",
		};
		
		public Calculator() {
			tField = new JTextFiedl(35);
		}

	}

}*/
